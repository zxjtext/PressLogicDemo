//
//  BaseModel.swift
//  Hanshin
//
//  Created by 张祥军 on 2021/5/14.
//

import Foundation
import HandyJSON

class BaseModel:HandyJSON{
    required init() {
        
    }
}
