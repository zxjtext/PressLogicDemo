//
//  BaseViewController.swift
//  EY.Mtel_ProjectTemplate_Swift
//
//  Created by zxj on 2020/8/3.
//  Copyright © 2020 EY.Mtel. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
}
