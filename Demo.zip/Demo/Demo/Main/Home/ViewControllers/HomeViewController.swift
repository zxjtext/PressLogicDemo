//
//  HomeViewController.swift
//  Demo
//
//  Created by 张祥军 on 2021/5/17.
//

import UIKit

class HomeViewController: BaseViewController {

    @IBOutlet var tableView: UITableView!
    var topItemArry:[entryModelArray]?
    lazy var ItemHeadView:appItemHeadView = {
        let ItemHeadView = appItemHeadView()
        return ItemHeadView
    }()
    lazy var RecommendHeadView:appItemRecommendHeadView = {
        let RecommendHeadView = appItemRecommendHeadView()
        return RecommendHeadView
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        let appItemCell = UINib(nibName: "appItemTableViewCell", bundle: nil)
        tableView.register(appItemCell, forCellReuseIdentifier: NSStringFromClass(appItemTableViewCell.self))
        loadData()
    }
}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.001
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 40
        }
        return 180
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 1 {
            guard let tempArray = topItemArry else {
                return 0
            }
            return tempArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            return RecommendHeadView
        }
        return ItemHeadView
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier:  NSStringFromClass(appItemTableViewCell.self), for: indexPath) as! appItemTableViewCell
           guard let tempArray = topItemArry else {
            return cell
            }
            let model = tempArray[indexPath.row]
            cell.setData(model: model, cell: cell, indexPath: indexPath)
            return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
    }
}

extension HomeViewController{
    func loadData(){
        ViewModel.shared.fetchTopfreeapplicationsData { (data) in
            guard let tempArray = data else {
                return
            }
            self.topItemArry = (tempArray as! topGrossingApplicationsModelArray).entry
            self.tableView.reloadData()
        }
    }
}
