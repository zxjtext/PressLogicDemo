//
//  appItemHeadCollectionViewCell.swift
//  Demo
//
//  Created by 张祥军 on 2021/5/18.
//

import UIKit

class appItemHeadCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
