//
//  appItemTableViewCell.swift
//  Demo
//
//  Created by 张祥军 on 2021/5/17.
//

import UIKit

class appItemTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
